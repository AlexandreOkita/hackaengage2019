<h1>Hackathon da Campus Party!!! \O/ </h1>

Obs: eu e o Caio vamos tentar deixar organizado dessa vez

![alt text](https://scontent.fcgh1-1.fna.fbcdn.net/v/t1.0-9/69243851_504268103723120_3668053043179421696_n.jpg?_nc_cat=111&_nc_eui2=AeF6XUM0XKj8Ut9T4DsRu5ZkhYZI2Dy-w3n68vlJmbNe-Yk0nIs_muCPCxFsp7b_HV83_zJj_EeUweo2R-XR1BYG09zQDRUcXe0zBc9h0ogCkw&_nc_oc=AQlhH4geQrtBjJwnrKuybNoCjSSsfJqoVi6bFyamhsXNlaXHEyGiXRBymbYlDIrnMfs&_nc_ht=scontent.fcgh1-1.fna&oh=fd96920a4e517a909cf42ab452401aea&oe=5E0EE360)
